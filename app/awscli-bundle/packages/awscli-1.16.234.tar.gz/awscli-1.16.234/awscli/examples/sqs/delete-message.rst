**To delete a message**

This example deletes the specified message.

Command::

  aws sqs delete-message --queue-url https://sqs.us-east-1.amazonaws.com/80398EXAMPLE/MyQueue --receipt-handle AQEBRXTo...q2doVA==

Output::

  None.